package com.example.calculator

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var textDisplay: TextView

    private var operand1: Double = 0.0
    private var operator: String? = null
    private var isOperand1Set: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textDisplay = findViewById(R.id.textDisplay)
    }

    fun onButtonClick(view: View) {
        val button = view as Button
        val buttonText = button.text.toString()

        when (buttonText) {
            "C" -> {
                clearDisplay()
            }
            "+/-" -> {
                // Change sign
            }
            "%" -> {
                // Handle percentage
            }
            "=" -> {
                performOperation()
            }
            "+", "-", "*", "/" -> {
                handleOperator(buttonText)
            }
            else -> {
                appendDigit(buttonText)
            }
        }
    }

    private fun appendDigit(digit: String) {
        val currentText = textDisplay.text.toString()
        textDisplay.text = currentText + digit
    }

    private fun clearDisplay() {
        textDisplay.text = ""
        operand1 = 0.0
        operator = null
        isOperand1Set = false
    }

    private fun handleOperator(op: String) {
        operator = op
        // Save operand1 and clear display for operand2
        operand1 = textDisplay.text.toString().toDouble()
        textDisplay.text = ""
        isOperand1Set = true
    }

    private fun performOperation() {
        if (!isOperand1Set || operator == null) return

        val operand2 = textDisplay.text.toString().toDouble()
        var result = 0.0

        when (operator) {
            "+" -> result = operand1 + operand2
            "-" -> result = operand1 - operand2
            "*" -> result = operand1 * operand2
            "/" -> {
                if (operand2 != 0.0) {
                    result = operand1 / operand2
                } else {
                    textDisplay.text = "Error"
                    return
                }
            }
        }

        textDisplay.text = result.toString()
        operand1 = result
        isOperand1Set = false
        operator = null
    }
}
